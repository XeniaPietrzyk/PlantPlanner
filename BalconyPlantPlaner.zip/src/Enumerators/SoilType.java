package Enumerators;

public enum SoilType {
    universal,
    sandy,
    peaty,
    clay,
    other;
}
