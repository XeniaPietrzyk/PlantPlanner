package Enumerators;

public enum Family {
    onion,
    potato,
    cabbage,
    daisy,
    carrot,
    others;
}
