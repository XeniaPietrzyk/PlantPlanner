package Enumerators;

public enum SoilMoisture {
    wet,
    moist,
    dry,
    other;
}
