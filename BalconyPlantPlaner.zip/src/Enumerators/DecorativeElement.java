package Enumerators;

public enum DecorativeElement {
    flowers,
    leafs,
    flowersAndLeafs,
    others;
}
