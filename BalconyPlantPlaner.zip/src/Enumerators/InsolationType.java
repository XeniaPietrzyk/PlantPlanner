package Enumerators;

public enum InsolationType {
    sunny,
    halflight,
    shadow,
    other;
}
