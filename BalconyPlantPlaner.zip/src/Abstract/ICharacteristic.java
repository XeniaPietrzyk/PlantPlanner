package Abstract;

public interface ICharacteristic {
    public void printCharacteristic();
}
